// DOM Elements
const chatMessages = document.getElementById("chatMessages");
const chatInput = document.getElementById("chatInput");
const sendBtn = document.getElementById("sendBtn");
const typingIndicator = document.getElementById("typingIndicator");
const newChatBtn = document.getElementById("newChatBtn");
const chatHistory = document.getElementById("chatHistory");
const mobileMenuBtn = document.getElementById("mobileMenuBtn");
const sidebar = document.getElementById("sidebar");

// State Management
let currentSessionId = generateSessionId();
let history = [];
let sessions = [];
let isFirstMessage = true;

// Initialize
document.addEventListener("DOMContentLoaded", () => {
    loadSessions();
    setupEventListeners();
    adjustTextareaHeight();
});

// Event Listeners
function setupEventListeners() {
    sendBtn.addEventListener("click", sendMessage);
    newChatBtn.addEventListener("click", createNewChat);
    
    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    chatInput.addEventListener("input", adjustTextareaHeight);
    
    // Suggestion cards
    document.querySelectorAll(".suggestion-card").forEach(card => {
        card.addEventListener("click", () => {
            const suggestion = card.getAttribute("data-suggestion");
            chatInput.value = suggestion;
            chatInput.focus();
            sendMessage();
        });
    });
    
    // Mobile menu toggle
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener("click", () => {
            sidebar.classList.toggle("mobile-hidden");
        });
    }
    
    // Close sidebar on mobile when clicking outside
    document.addEventListener("click", (e) => {
        if (window.innerWidth <= 768) {
            if (!sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                sidebar.classList.add("mobile-hidden");
            }
        }
    });
}

// Generate unique session ID
function generateSessionId() {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Adjust textarea height dynamically
function adjustTextareaHeight() {
    chatInput.style.height = "auto";
    chatInput.style.height = Math.min(chatInput.scrollHeight, 150) + "px";
}

// Create new chat session
function createNewChat() {
    currentSessionId = generateSessionId();
    history = [];
    isFirstMessage = true;
    
    // Clear messages and show empty state
    chatMessages.innerHTML = `
        <div class="empty-state">
            <div class="empty-state-icon">
                <i class="fas fa-robot"></i>
            </div>
            <h2>Welcome to AOC AI Assistant</h2>
            <p>Your intelligent companion for coding, writing, analysis, and more. Start a conversation below or try one of these suggestions.</p>
            
            <div class="suggestions">
                <div class="suggestion-card" data-suggestion="Help me write a Python function to sort a list">
                    <div class="suggestion-icon">💻</div>
                    <div class="suggestion-text">Help me write a Python function</div>
                </div>
                <div class="suggestion-card" data-suggestion="Explain quantum computing in simple terms">
                    <div class="suggestion-icon">🔬</div>
                    <div class="suggestion-text">Explain quantum computing</div>
                </div>
                <div class="suggestion-card" data-suggestion="Give me tips for better productivity">
                    <div class="suggestion-icon">⚡</div>
                    <div class="suggestion-text">Productivity tips</div>
                </div>
                <div class="suggestion-card" data-suggestion="Help me debug this code error">
                    <div class="suggestion-icon">🐛</div>
                    <div class="suggestion-text">Debug code issues</div>
                </div>
            </div>
        </div>
    `;
    
    // Re-attach suggestion card listeners
    document.querySelectorAll(".suggestion-card").forEach(card => {
        card.addEventListener("click", () => {
            const suggestion = card.getAttribute("data-suggestion");
            chatInput.value = suggestion;
            chatInput.focus();
            sendMessage();
        });
    });
    
    loadSessions();
    chatInput.focus();
}

// Add message to UI
function addMessage(role, content) {
    // Remove empty state if present
    if (isFirstMessage) {
        chatMessages.innerHTML = "";
        isFirstMessage = false;
    }
    
    const messageGroup = document.createElement("div");
    messageGroup.classList.add("message-group");
    
    const message = document.createElement("div");
    message.classList.add("message", role);
    
    const avatar = document.createElement("div");
    avatar.classList.add("message-avatar");
    avatar.innerHTML = role === "user" 
        ? '<i class="fas fa-user"></i>' 
        : '<i class="fas fa-robot"></i>';
    
    const messageContent = document.createElement("div");
    messageContent.classList.add("message-content");
    
    const messageRole = document.createElement("div");
    messageRole.classList.add("message-role");
    messageRole.textContent = role === "user" ? "You" : "AI Assistant";
    
    const messageText = document.createElement("div");
    messageText.classList.add("message-text");
    messageText.textContent = content;
    
    messageContent.appendChild(messageRole);
    messageContent.appendChild(messageText);
    
    message.appendChild(avatar);
    message.appendChild(messageContent);
    messageGroup.appendChild(message);
    
    chatMessages.appendChild(messageGroup);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Send message
async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;
    
    // Add user message
    addMessage("user", text);
    history.push({ role: "user", content: text });
    
    // Clear input
    chatInput.value = "";
    adjustTextareaHeight();
    chatInput.focus();
    
    // Show typing indicator
    typingIndicator.classList.add("active");
    sendBtn.disabled = true;
    
    // Close mobile sidebar
    if (window.innerWidth <= 768) {
        sidebar.classList.add("mobile-hidden");
    }
    
    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                message: text,
                history: history,
                session_id: currentSessionId
            }),
        });
        
        const data = await response.json();
        
        if (data.error) {
            addMessage("assistant", `⚠️ Error: ${data.error}`);
            return;
        }
        
        const reply = data.reply || "";
        addMessage("assistant", reply);
        history.push({ role: "assistant", content: reply });
        
        // Update sessions list
        loadSessions();
        
    } catch (err) {
        console.error("Network error:", err);
        addMessage("assistant", "⚠️ Network error. Please check your connection and try again.");
    } finally {
        typingIndicator.classList.remove("active");
        sendBtn.disabled = false;
    }
}

// Load chat sessions
async function loadSessions() {
    try {
        const response = await fetch("/api/sessions");
        const data = await response.json();
        sessions = data.sessions || [];
        renderSessions();
    } catch (err) {
        console.error("Failed to load sessions:", err);
    }
}

// Render sessions in sidebar
function renderSessions() {
    if (sessions.length === 0) {
        chatHistory.innerHTML = '<div style="padding: 12px; color: #6b7280; font-size: 12px; text-align: center;">No chat history yet</div>';
        return;
    }
    
    chatHistory.innerHTML = sessions.map(session => {
        const date = new Date(session.created);
        const dateStr = formatDate(date);
        const isActive = session.id === currentSessionId;
        
        return `
            <div class="chat-item ${isActive ? 'active' : ''}" data-session-id="${session.id}">
                <div class="chat-item-content">
                    <div class="chat-item-title">${session.title}</div>
                    <div class="chat-item-date">${dateStr} • ${session.message_count} messages</div>
                </div>
                <i class="fas fa-trash chat-item-delete" data-session-id="${session.id}"></i>
            </div>
        `;
    }).join("");
    
    // Attach event listeners
    document.querySelectorAll(".chat-item").forEach(item => {
        item.addEventListener("click", (e) => {
            if (!e.target.classList.contains("chat-item-delete")) {
                loadSession(item.getAttribute("data-session-id"));
            }
        });
    });
    
    document.querySelectorAll(".chat-item-delete").forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            deleteSession(btn.getAttribute("data-session-id"));
        });
    });
}

// Format date
function formatDate(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

// Load specific session
async function loadSession(sessionId) {
    try {
        const response = await fetch(`/api/sessions/${sessionId}`);
        const data = await response.json();
        
        if (data.error) {
            console.error("Session not found");
            return;
        }
        
        currentSessionId = sessionId;
        history = data.messages.map(msg => ({
            role: msg.role,
            content: msg.content
        }));
        
        isFirstMessage = true;
        chatMessages.innerHTML = "";
        
        // Render messages
        data.messages.forEach(msg => {
            addMessage(msg.role, msg.content);
        });
        
        renderSessions();
        
        // Close mobile sidebar
        if (window.innerWidth <= 768) {
            sidebar.classList.add("mobile-hidden");
        }
        
    } catch (err) {
        console.error("Failed to load session:", err);
    }
}

// Delete session
async function deleteSession(sessionId) {
    if (!confirm("Are you sure you want to delete this chat?")) return;
    
    try {
        await fetch(`/api/sessions/${sessionId}`, {
            method: "DELETE"
        });
        
        if (sessionId === currentSessionId) {
            createNewChat();
        } else {
            loadSessions();
        }
    } catch (err) {
        console.error("Failed to delete session:", err);
    }
}